*******
Builder
*******

Modules
=======

finn.builder.build\_dataflow
----------------------------

.. automodule:: finn.builder.build_dataflow
   :members:
   :undoc-members:
   :show-inheritance:

finn.builder.build\_dataflow\_config
------------------------------------

.. automodule:: finn.builder.build_dataflow_config
 :members:
 :undoc-members:
 :show-inheritance:


finn.builder.build\_dataflow\_steps
------------------------------------

.. automodule:: finn.builder.build_dataflow_steps
  :members:
  :undoc-members:
  :show-inheritance:
