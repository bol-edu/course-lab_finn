************************
Custom Op - General
************************

General Custom Ops
===================

qonnx.custom\_op.general.bipolar_quant
--------------------------------------

.. automodule:: qonnx.custom_op.general.bipolar_quant
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.custom\_op.general.debugmarker
------------------------------------

.. automodule:: qonnx.custom_op.general.debugmarker
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.custom\_op.general.genericpartition
-----------------------------------------

.. automodule:: qonnx.custom_op.general.genericpartition
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.custom\_op.general.im2col
-------------------------------

.. automodule:: qonnx.custom_op.general.im2col
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.custom\_op.general.maxpoolnhwc
------------------------------------

.. automodule:: qonnx.custom_op.general.maxpoolnhwc
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.custom\_op.general.multithreshold
---------------------------------------

.. automodule:: qonnx.custom_op.general.multithreshold
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.custom\_op.general.quant
------------------------------

.. automodule:: qonnx.custom_op.general.quant
  :members:
  :undoc-members:
  :show-inheritance:

qonnx.custom\_op.general.quantavgpool2d
---------------------------------------

.. automodule:: qonnx.custom_op.general.quantavgpool2d
  :members:
  :undoc-members:
  :show-inheritance:

qonnx.custom\_op.general.trunc
------------------------------

.. automodule:: qonnx.custom_op.general.trunc
  :members:
  :undoc-members:
  :show-inheritance:

qonnx.custom\_op.general.xnorpopcount
-------------------------------------

.. automodule:: qonnx.custom_op.general.xnorpopcount
   :members:
   :undoc-members:
   :show-inheritance:
